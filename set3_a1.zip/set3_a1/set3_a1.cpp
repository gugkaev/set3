#include <iostream>
#include <fstream>
#include <random>
#include <cmath>
#include <iomanip>
#include <algorithm>
#include <vector>
#include <string>
struct Circle {
  double x, y, r;
};
bool isInside(const Circle& c, double px, double py) {
  double dx = px - c.x;
  double dy = py - c.y;
  return dx * dx + dy * dy <= c.r * c.r;
}
int main() {
  Circle circles[3] = {{1.0, 1.0, 1.0}, {1.5, 2.0, std::sqrt(5.0) / 2.0}, {2.0, 1.5, std::sqrt(5.0) / 2.0}};
  const double exact_area = 0.25 * M_PI + 1.25 * std::asin(0.8) - 1.0;
  double narrow_x_left =
      std::max({circles[0].x - circles[0].r, circles[1].x - circles[1].r, circles[2].x - circles[2].r});
  double narrow_x_right =
      std::min({circles[0].x + circles[0].r, circles[1].x + circles[1].r, circles[2].x + circles[2].r});
  double narrow_y_bottom =
      std::max({circles[0].y - circles[0].r, circles[1].y - circles[1].r, circles[2].y - circles[2].r});
  double narrow_y_top =
      std::min({circles[0].y + circles[0].r, circles[1].y + circles[1].r, circles[2].y + circles[2].r});
  if (narrow_x_left >= narrow_x_right || narrow_y_bottom >= narrow_y_top) {
    std::cout << "Warning: Narrow region is empty.\n";
  }
  double wide_x_left =
      std::min({circles[0].x - circles[0].r, circles[1].x - circles[1].r, circles[2].x - circles[2].r});
  double wide_x_right =
      std::max({circles[0].x + circles[0].r, circles[1].x + circles[1].r, circles[2].x + circles[2].r});
  double wide_y_bottom =
      std::min({circles[0].y - circles[0].r, circles[1].y - circles[1].r, circles[2].y - circles[2].r});
  double wide_y_top = std::max({circles[0].y + circles[0].r, circles[1].y + circles[1].r, circles[2].y + circles[2].r});
  std::cout << "Narrow box: [" << narrow_x_left << ", " << narrow_x_right << "] x [" << narrow_y_bottom << ", "
            << narrow_y_top << "]\n";
  std::cout << "Wide box: [" << wide_x_left << ", " << wide_x_right << "] x [" << wide_y_bottom << ", " << wide_y_top
            << "]\n";
  std::cout << "Exact area = " << std::setprecision(10) << exact_area << "\n";
  std::mt19937 gen(12345);
  const int N_start = 100;
  const int N_end = 100000;
  const int N_step = 500;
  std::ofstream csv("monte_carlo_comparison.csv");
  csv << "N,region,ApproxArea,RelError\n";
  auto run_experiment = [&](double x1, double x2, double y1, double y2, const std::string& region_name) {
    std::uniform_real_distribution<double> disX(x1, x2);
    std::uniform_real_distribution<double> disY(y1, y2);
    double rect_area = (x2 - x1) * (y2 - y1);

    for (int N = N_start; N <= N_end; N += N_step) {
      long long count = 0;
      for (int i = 0; i < N; ++i) {
        double px = disX(gen);
        double py = disY(gen);
        if (isInside(circles[0], px, py) && isInside(circles[1], px, py) && isInside(circles[2], px, py)) {
          ++count;
        }
      }
      double approx = static_cast<double>(count) / N * rect_area;
      double rel_err = std::abs(approx - exact_area) / exact_area;
      csv << N << "," << region_name << "," << std::setprecision(10) << approx << "," << rel_err << "\n";
    }
  };
  run_experiment(narrow_x_left, narrow_x_right, narrow_y_bottom, narrow_y_top, "narrow");
  run_experiment(wide_x_left, wide_x_right, wide_y_bottom, wide_y_top, "wide");
  csv.close();
  std::cout << "Data saved to 'monte_carlo_comparison.csv'\n";
  return 0;
}