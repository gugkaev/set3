#include <vector>
#include <algorithm>
#include <random>
#include <chrono>
#include <numeric>
#include <iostream>
#include <fstream>
#include <map>
void merge(std::vector<int>& arr, int l, int m, int r) {
  int n1 = m - l + 1;
  int n2 = r - m;
  std::vector<int> L(n1), R(n2);
  for (int i = 0; i < n1; i++)
    L[i] = arr[l + i];
  for (int j = 0; j < n2; j++)
    R[j] = arr[m + 1 + j];
  int i = 0, j = 0, k = l;
  while (i < n1 && j < n2) {
    if (L[i] <= R[j])
      arr[k++] = L[i++];
    else
      arr[k++] = R[j++];
  }
  while (i < n1)
    arr[k++] = L[i++];
  while (j < n2)
    arr[k++] = R[j++];
}
void mergeSort(std::vector<int>& arr, int l, int r) {
  if (l >= r)
    return;
  int m = l + (r - l) / 2;
  mergeSort(arr, l, m);
  mergeSort(arr, m + 1, r);
  merge(arr, l, m, r);
}
void insertionSort(std::vector<int>& arr, int l, int r) {
  for (int i = l + 1; i <= r; i++) {
    int key = arr[i];
    int j = i - 1;
    while (j >= l && arr[j] > key) {
      arr[j + 1] = arr[j];
      j--;
    }
    arr[j + 1] = key;
  }
}
void hybridMergeSort(std::vector<int>& arr, int l, int r, int threshold = 10) {
  if (r - l + 1 <= threshold) {
    insertionSort(arr, l, r);
    return;
  }
  if (l >= r)
    return;
  int m = l + (r - l) / 2;
  hybridMergeSort(arr, l, m, threshold);
  hybridMergeSort(arr, m + 1, r, threshold);
  merge(arr, l, m, r);
}
class ArrayGenerator {
 private:
  static std::mt19937 rng;
 public:
  static std::vector<int> generateRandom(int n, int min_val = 0, int max_val = 6000) {
    std::uniform_int_distribution<int> dist(min_val, max_val);
    std::vector<int> arr(n);
    for (int& x : arr)
      x = dist(rng);
    return arr;
  }
  static std::vector<int> generateReverseSorted(int n) {
    std::vector<int> arr(n);
    std::iota(arr.rbegin(), arr.rend(), 0);
    return arr;
  }
  static std::vector<int> generateNearlySorted(int n, int swaps = 10) {
    std::vector<int> arr(n);
    std::iota(arr.begin(), arr.end(), 0);
    std::uniform_int_distribution<int> dist(0, n - 1);
    for (int i = 0; i < swaps; i++) {
      int i1 = dist(rng), i2 = dist(rng);
      std::swap(arr[i1], arr[i2]);
    }
    return arr;
  }
};
std::mt19937 ArrayGenerator::rng(42);
class SortTester {
 private:
  static long long measureTime(void (*sortFunc)(std::vector<int>&, int, int), const std::vector<int>& original, int l,
                               int r) {
    std::vector<int> arr = original;
    auto start = std::chrono::high_resolution_clock::now();
    sortFunc(arr, l, r);
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
  }
  static long long measureHybridTime(const std::vector<int>& original, int l, int r, int threshold) {
    std::vector<int> arr = original;
    auto start = std::chrono::high_resolution_clock::now();
    hybridMergeSort(arr, l, r, threshold);
    auto end = std::chrono::high_resolution_clock::now();
    return std::chrono::duration_cast<std::chrono::microseconds>(end - start).count();
  }
 public:
  static long long benchmarkMergeSort(const std::vector<int>& arr, int runs = 5) {
    long long total = 0;
    for (int i = 0; i < runs; i++) {
      total += measureTime(mergeSort, arr, 0, arr.size() - 1);
    }
    return total / runs;
  }
  static long long benchmarkHybridSort(const std::vector<int>& arr, int threshold, int runs = 5) {
    long long total = 0;
    for (int i = 0; i < runs; i++) {
      total += measureHybridTime(arr, 0, arr.size() - 1, threshold);
    }
    return total / runs;
  }
};

int main() {
  const int MAX_N = 100000;
  const int STEP = 100;
  const int MIN_N = 500;
  const std::vector<int> thresholds = {5, 10, 20, 30, 50};
  auto fullRandom = ArrayGenerator::generateRandom(MAX_N);
  auto fullReverse = ArrayGenerator::generateReverseSorted(MAX_N);
  auto fullNearly = ArrayGenerator::generateNearlySorted(MAX_N, 50);
  std::ofstream f_merge_rand("merge_random.csv");
  std::ofstream f_merge_rev("merge_reverse.csv");
  std::ofstream f_merge_near("merge_nearly.csv");
  std::map<int, std::ofstream> f_hybrid_rand, f_hybrid_rev, f_hybrid_near;
  for (int t : thresholds) {
    f_hybrid_rand[t].open("hybrid_t" + std::to_string(t) + "_random.csv");
    f_hybrid_rev[t].open("hybrid_t" + std::to_string(t) + "_reverse.csv");
    f_hybrid_near[t].open("hybrid_t" + std::to_string(t) + "_nearly.csv");
  }
  auto writeHeader = [](std::ofstream& f) { f << "n,time_us\n"; };
  writeHeader(f_merge_rand);
  writeHeader(f_merge_rev);
  writeHeader(f_merge_near);
  for (int t : thresholds) {
    writeHeader(f_hybrid_rand[t]);
    writeHeader(f_hybrid_rev[t]);
    writeHeader(f_hybrid_near[t]);
  }
  for (int n = MIN_N; n <= MAX_N; n += STEP) {
    {
      std::vector<int> arr(fullRandom.begin(), fullRandom.begin() + n);
      long long t_merge = SortTester::benchmarkMergeSort(arr);
      f_merge_rand << n << "," << t_merge << "\n";
      for (int t : thresholds) {
        long long t_hybrid = SortTester::benchmarkHybridSort(arr, t);
        f_hybrid_rand[t] << n << "," << t_hybrid << "\n";
      }
    }
    {
      std::vector<int> arr(fullReverse.begin(), fullReverse.begin() + n);
      long long t_merge = SortTester::benchmarkMergeSort(arr);
      f_merge_rev << n << "," << t_merge << "\n";
      for (int t : thresholds) {
        long long t_hybrid = SortTester::benchmarkHybridSort(arr, t);
        f_hybrid_rev[t] << n << "," << t_hybrid << "\n";
      }
    }
    {
      std::vector<int> arr(fullNearly.begin(), fullNearly.begin() + n);
      long long t_merge = SortTester::benchmarkMergeSort(arr);
      f_merge_near << n << "," << t_merge << "\n";
      for (int t : thresholds) {
        long long t_hybrid = SortTester::benchmarkHybridSort(arr, t);
        f_hybrid_near[t] << n << "," << t_hybrid << "\n";
      }
    }
  }
  f_merge_rand.close();
  f_merge_rev.close();
  f_merge_near.close();
  for (int t : thresholds) {
    f_hybrid_rand[t].close();
    f_hybrid_rev[t].close();
    f_hybrid_near[t].close();
  }
}