#include <iostream>
#include <vector>
#include <random>
#include <chrono>
#include <fstream>
#include <cmath>
#include <algorithm>
#include <numeric>
#include <string>



int partition(std::vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;
    for (int j = low; j < high; ++j) {
        if (arr[j] <= pivot) {
            ++i;
            std::swap(arr[i], arr[j]);
        }
    }
    std::swap(arr[i + 1], arr[high]);
    return i + 1;
}

void quickSort(std::vector<int>& arr, int low, int high) {
    if (low < high) {
        int randomIndex = low + std::rand() % (high - low + 1);
        std::swap(arr[randomIndex], arr[high]);

        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

void insertionSort(std::vector<int>& arr, int low, int high) {
    for (int i = low + 1; i <= high; ++i) {
        int key = arr[i];
        int j = i - 1;
        while (j >= low && arr[j] > key) {
            arr[j + 1] = arr[j];
            --j;
        }
        arr[j + 1] = key;
    }
}

void heapify(std::vector<int>& arr, int n, int i) {
    int largest = i;
    int l = 2 * i + 1;
    int r = 2 * i + 2;

    if (l < n && arr[l] > arr[largest]) largest = l;
    if (r < n && arr[r] > arr[largest]) largest = r;

    if (largest != i) {
        std::swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

void heapSort(std::vector<int>& arr, int low, int high) {
    int n = high - low + 1;
    std::vector<int> temp(arr.begin() + low, arr.begin() + high + 1);

    for (int i = n / 2 - 1; i >= 0; --i)
        heapify(temp, n, i);

    for (int i = n - 1; i > 0; --i) {
        std::swap(temp[0], temp[i]);
        heapify(temp, i, 0);
    }

    std::copy(temp.begin(), temp.end(), arr.begin() + low);
}

void introsort(std::vector<int>& arr, int low, int high, int depthLimit) {
    int size = high - low + 1;

    if (size < 16) {
        insertionSort(arr, low, high);
        return;
    }

    if (depthLimit == 0) {
        heapSort(arr, low, high);
        return;
    }

    int randomIndex = low + std::rand() % (high - low + 1);
    std::swap(arr[randomIndex], arr[high]);
    int pi = partition(arr, low, high);

    introsort(arr, low, pi - 1, depthLimit - 1);
    introsort(arr, pi + 1, high, depthLimit - 1);
}

void introsortWrapper(std::vector<int>& arr) {
    if (arr.empty()) return;
    int n = static_cast<int>(arr.size());
    int depthLimit = 2 * static_cast<int>(std::log2(n));
    introsort(arr, 0, n - 1, depthLimit);
}

class SortTester {
public:
    using Clock = std::chrono::high_resolution_clock;
    using Duration = std::chrono::nanoseconds;

    static Duration measureQuickSort(std::vector<int> data) {
        auto start = Clock::now();
        quickSort(data, 0, static_cast<int>(data.size()) - 1);
        auto end = Clock::now();
        return std::chrono::duration_cast<Duration>(end - start);
    }

    static Duration measureIntrosort(std::vector<int> data) {
        auto start = Clock::now();
        introsortWrapper(data);
        auto end = Clock::now();
        return std::chrono::duration_cast<Duration>(end - start);
    }

    static std::vector<std::vector<int>> generateTestCases(
        const std::vector<int>& sizes,
        const std::string& type = "random") {
        std::vector<std::vector<int>> all;
        std::mt19937 rng(42);

        for (int n : sizes) {
            std::vector<int> arr(n);
            if (type == "random") {
                std::uniform_int_distribution<int> dist(0, 1000000);
                for (int& x : arr) x = dist(rng);
            } else if (type == "sorted") {
                std::iota(arr.begin(), arr.end(), 1);
            } else if (type == "reverse") {
                std::iota(arr.rbegin(), arr.rend(), 1);
            }
            all.push_back(arr);
        }
        return all;
    }

    static void saveResultsToFile(const std::string& filename,
                                  const std::vector<int>& sizes,
                                  const std::vector<long long>& quickTimes,
                                  const std::vector<long long>& introTimes) {
        std::ofstream file(filename);
        file << "N,QuickSort_ns,Introsort_ns\n";
        for (size_t i = 0; i < sizes.size(); ++i) {
            file << sizes[i] << "," << quickTimes[i] << "," << introTimes[i] << "\n";
        }
    }
};

int main() {
    std::srand(static_cast<unsigned>(std::time(nullptr)));

    std::filesystem::create_directories("data");

    std::vector<int> sizes = {100, 500, 1000, 5000, 10000, 50000, 100000};
    std::vector<std::string> types = {"random", "sorted", "reverse"};

    for (const auto& type : types) {
        std::cout << "Обработка: " << type << "...\n";
        auto testCases = SortTester::generateTestCases(sizes, type);

        std::vector<long long> quickTimes, introTimes;

        for (size_t i = 0; i < testCases.size(); ++i) {
            auto qt = SortTester::measureQuickSort(testCases[i]);
            auto it = SortTester::measureIntrosort(testCases[i]);

            quickTimes.push_back(qt.count());
            introTimes.push_back(it.count());
        }

        std::string filename = "data/" + type + ".csv";
        SortTester::saveResultsToFile(filename, sizes, quickTimes, introTimes);
        std::cout << "Сохранено: " << filename << "\n";
    }

    std::cout << "\nФайлы сохранены, ура.\n";
    return 0;
}